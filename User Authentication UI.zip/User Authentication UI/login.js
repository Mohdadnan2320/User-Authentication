import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAuth, signInWithEmailAndPassword } from 'https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js'
import { getDatabase, get, ref, child } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-database.js";

const firebaseConfig = {
    apiKey: "AIzaSyBc5rrSzQ6n4tzu4DwsjSQ3i7-metW6-Bs",
    authDomain: "user-authentication-ui-8c39a.firebaseapp.com",
    projectId:"user-authentication-ui-8c39a",
    storageBucket:"user-authentication-ui-8c39a.appspot.com",
    messagingSenderId: "574387214425",
    appId: "1:574387214425:web:61326dc1d04b635c31b948"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);

function showMessage(message, divId) {
    var messageDiv = document.getElementById(divId);
    messageDiv.style.display = 'block'
    messageDiv.innerHTML = message;
    messageDiv.style.opacity = 1
    setTimeout(function () {
        messageDiv.style.opacity = 0
    }, 5000)
}

//LOGIN USER
const signIn = document.getElementById('signIn');
signIn.addEventListener('click', function (event) {
    event.preventDefault();
    const email = document.getElementById('rEmail').value;
    const password = document.getElementById('rPassword').value;

    const auth = getAuth();
    const db = getDatabase();
    const dbref = ref(db);

    signInWithEmailAndPassword(auth, email, password)
        .then((userCredential) => {
           get(child(dbref, 'UserAuthList/' + userCredential.user.uid))
           .then((snapshot)=>{
            if(snapshot.exists){
                sessionStorage.setItem('user-info', JSON.stringify({
                    email: snapshot.val().email,
                    username: snapshot.val().username,
                }))
                sessionStorage.setItem("user-creds", JSON.stringify(userCredential.user));
                window.location.href='dashboard.html'
                showMessage('Login Successfully', 'signUpMessage');

            }
           })
            
        })
        .catch((error) => {
            const errorCode = error.code;
            const errorMessage = error.message;
            showMessage(error, 'signUpMessage');

        });

})



