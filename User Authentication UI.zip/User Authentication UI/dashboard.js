let UserCreds = JSON.parse(sessionStorage.getItem("user-creds"));
        let UserInfo = JSON.parse(sessionStorage.getItem("user-info"));

        let GreetHead = document.getElementById('user-Data')
        let SignOutBtn = document.getElementById('signout')

        GreetHead.innerHTML = `Welcome ${UserInfo.username}`

        let SignOut = () => {
            sessionStorage.removeItem('user-cred')
            sessionStorage.removeItem("user-info")
            window.location.href = 'index.html'
        }

        let CheckCred = () => {
            if (sessionStorage.getItem('user-cred'))
                window.location.href = 'index.html'

            else {
                GreetHead.innerHTML = `Welcome user: "${UserInfo.username}"`

            }
        }

        window.addEventListener('load', CheckCred);

        SignOutBtn.addEventListener('click', SignOut)
